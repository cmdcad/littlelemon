//
//  Dish+CoreDataClass.swift
//  LittleLemonRestaurant
//
//  Created by Tosin Akinbobuyi on 10/3/23.
//
//

import Foundation
import CoreData

@objc(Dish)
public class Dish: NSManagedObject {

}
