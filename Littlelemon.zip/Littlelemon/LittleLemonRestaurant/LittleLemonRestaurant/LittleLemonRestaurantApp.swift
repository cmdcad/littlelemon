//
//  LittleLemonRestaurantApp.swift
//  LittleLemonRestaurant
//
//  Created by Tosin Akinbobuyi on 10/3/23.
//

import SwiftUI

@main
struct LittleLemonRestaurantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
