//
//  Model.swift
//  LittleLemonRestaurant
//
//  Created by Tosin Akinbobuyi on 10/4/23.
//

import Foundation


@MainActor class Model: ObservableObject {
    @Published var showHero: Bool = true
    @Published var showBackButton: Bool = false
}
