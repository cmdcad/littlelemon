//
//  MenuList.swift
//  LittleLemonRestaurant
//
//  Created by Tosin Akinbobuyi on 10/2/23.
//

import Foundation
struct MenuLIst:Decodable{
    let menu:[MenuItem]
}
