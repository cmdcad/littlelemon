import { StyleSheet, Alert, Pressable, View, TextInput, Image, Text, } from 'react-native';
import {useState} from 'react';
import validateEmail  from './utils';

function SubscribeScreen({ navigation }) {
  const [email, setEmail] = useState(null)
 
const validate = ()=>{ 
    //console.log(email);

    let m = email.match(
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  );
  
  if(m!=null && m){
    Alert.alert("Thanks for subscribing, stay tuned!")
    console.log("good !")
  }
  else{
    console.log("no");
  } 
}

  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/little-lemon-logo-grey.png')}
        style={styles.image}
        accessible={true}
        accessibilityLabel={'Little Lemon Logo'}
      />

      <Text style={styles.regularText}>
        Subscribe to our newletter for out latest delicious recipes!
      </Text>

      <View>
        <TextInput style={styles.input} value={email} onChangeText={setEmail}/>
        
        <Pressable onPress={validate}
          style={styles.button} >
          <Text style={styles.buttonText}>Subscribe</Text>
        </Pressable>
      </View>
    </View>
  );
}

export default SubscribeScreen;

const styles = StyleSheet.create({
  image: {
    resizeMode: 'contain',
    height: 120,
    width: 120,
  },
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  
  regularText: {
    fontSize: 18,
    color: '#495E57',
    textAlign: 'center', 
    padding: 45,
  },
  buttonText: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
    paddingVertical: 5
  },
  input: {
    borderColor: '#495E57',
    borderWidth:1,
    height:40,
    marginVertical: 20, 
    fontSize: 16, 
paddingHorizontal:10,
    borderRadius:12,
  },
  button: {
    backgroundColor: '#495E57',
    height: 40,
    paddingHorizontal: 80,
    borderRadius: 5,
  },
});
