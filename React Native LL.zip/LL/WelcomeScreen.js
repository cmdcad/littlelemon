import React from 'react';
import { View, Text, Pressable, Image, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

const WelcomeScreen = ({ navigation }) => {
  // Add welcome screen code here.
  const onClick = () => {
    navigation.navigate('SubscribeScreen');
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/little-lemon-logo.png')}
        style={styles.image}
        accessible={true}
        accessibilityLabel={'Little Lemon Logo'}
      />

      <Text style={styles.regularText}>
        Little Lemon, your local Mediterranean Bistro
      </Text>

      <Pressable style={styles.button} onPress={onClick}>
        <Text style={styles.buttonText}>Newsletter</Text>
      </Pressable>
    </View>
  );
};

export default WelcomeScreen;

const styles = StyleSheet.create({
  image: {
    resizeMode: 'contain',
    height: 200,
    width: 200,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  regularText: {
    fontSize: 18,
    color: '#495E57',
    textAlign: 'center',
    width: 280,
    padding: 45,
    fontWeight:'medium'
  },
  buttonText: {
    fontSize: 15,
    color: '#fff',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#495E57',
    height: 35,
    paddingHorizontal: 80,
    borderRadius: 5,
    textAlign: 'center',
    justifyContent: 'center',
  },
});
