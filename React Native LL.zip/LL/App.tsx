import * as React from 'react';
import { Button, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SubscribeScreen from './SubscribeScreen'
import WelcomeScreen from './WelcomeScreen'


const Stack = createStackNavigator();

function MyStack() {
  return (
    <Stack.Navigator initialRouteName="WelcomeScreen" screenOptions={{
        headerTitleAlign: 'center'
      }}>
      <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} options={{
          title: 'Welcome',
        }}/>
      <Stack.Screen name="SubscribeScreen" component={SubscribeScreen} options={{
          title: "Subscribe",
        }} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer >
      <MyStack />
    </NavigationContainer>
  );
}
