I have added the 3 files into the folder. They include 
App.js,
WelcomeScreen.js,
SubscribeScreen.js

You may just replace the files in your own project or just copy the contents to your own instead. It will work just fine!

To view in expo snacks you can go to my link: https://snack.expo.dev/@mikeso/little-lemon

then: editor > panel > logs to view the logs


Thank You!!