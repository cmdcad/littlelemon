//
//  LittleLemonLogo.swift
//  M4Exercise
//
//  Created by Tosin Akinbobuyi on 9/29/23.
//

import Foundation
import SwiftUI

struct LittleLemonLogo: View {
    
    var body: some View {
        Image("littleLemon")
    }
}
