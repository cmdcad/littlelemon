//
//  M4ExerciseApp.swift
//  M4Exercise
//
//  Created by Tosin Akinbobuyi on 9/29/23.
//

import SwiftUI

@main
struct M4ExerciseApp: App {
    let persistenceController = PersistenceController.shared
 
     init() {
         //Dessert.deleteAll(persistenceController.container.viewContext)
         //Customer.deleteAll(persistenceController.container.viewContext)
        // Dessert.createDesserts(persistenceController.container.viewContext)
     }
  
    var body: some Scene {
        WindowGroup {
            MainView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
