import Foundation
import CoreData

@objc(Dessert)
public class Dessert: NSManagedObject {

}
