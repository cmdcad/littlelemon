import Foundation
import CoreData


extension Dish {

    static func createDishesFrom(menuItems:[MenuItem],
                                 _ context:NSManagedObjectContext) {
        Dish.deleteAll(context)
        
        for item in menuItems {
            if Dish.exists(name: item.title, context )!{
                continue
            }
            
            let dish = Dish(context: context)
            dish.name = item.title
            dish.price = Float(item.price)!
            dish.size = ""

            Dish.saveDatabase(context)
        }
    }
    
    static func hasMenuItem(_ x: MenuItem) -> Bool{
        return false
    }
    
    class func saveDatabase(_ context:NSManagedObjectContext) {
        guard context.hasChanges else { return}
        do {
            try context.save()
        } catch (let error) {
            print(error.localizedDescription)
        }
    }
    
}
