import SwiftUI
import CoreData

struct OurDishes: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @ObservedObject var dishesModel = DishesModel()
    @State private var showAlert = false
    @State var searchText = ""
    
    
    var body: some View {
        VStack {
            LittleLemonLogo()
                .padding(.bottom, 10)
                .padding(.top, 50)
            
            Text ("Tap to order")
                .foregroundColor(.black)
                .padding([.leading, .trailing], 40)
                .padding([.top, .bottom], 8)
                .background(Color("approvedYellow"))
                .cornerRadius(20)
            
            NavigationView {
                FetchedObjects(
                    predicate:buildPredicate(),
                    sortDescriptors: buildSortDescriptors()) {
                        (dishes: [Dish]) in
                        List {
                            ForEach(dishes, id:\.self) { dish in
                               DisplayDish(dish)
                                    .searchable(text: $searchText, prompt: "search...")
                            }
                        }
                        .listStyle(.plain)
                    }
            }
            
            .alert("Order placed, thanks!",
                   isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            }
                   .task {
                       await dishesModel.reload(viewContext)
                   }
        }
    }
   
    func buildPredicate() -> NSPredicate {
        if searchText == "" {
                          return NSPredicate(value: true)
                      }
                      return NSPredicate(format: "name CONTAINS[cd] %@", searchText)
    }
    
    
    func buildSortDescriptors() -> [NSSortDescriptor] {
        return [
                   NSSortDescriptor(key: "name",
                                    ascending: true,
                                    selector:
                     #selector(NSString .localizedCaseInsensitiveCompare)),
                   NSSortDescriptor(key: "size",
                                    ascending: true,
                                    selector:
                     #selector(NSString .localizedCaseInsensitiveCompare))
               ]
    }
    
}

struct OurDishes_Previews: PreviewProvider {
    static var previews: some View {
        OurDishes()
    }
}

