//
//  ReservationForm.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/16/23.
//

import SwiftUI

struct ReservationForm: View {
    @EnvironmentObject private var model:Model
    
    @State var showFormInvalidMessage: Bool = false
    @State var errorMessage: String = ""
    private var restaurant: RestaurantLocation
    @State var mustChangeReservation: Bool = false
    @State var selectedDate = Date()
    @State var name = ""
    @State var specialRequests: String = ""
    @State var phone = ""
    @State var email = ""
    @State var reservationDate = Date()
    @State var party: String = "1"
    
    @State var ErrorMap: Dictionary<Int, String> = [0: "Names can only contain letters and must have at least 3 characters", 1: "The phone number cannot be blank", 2: "The e-mail is Invalid and cannot be blank"]
    @State var ErrorCodes:[Int] = []
    
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
 
   
    init(_ restaurant: RestaurantLocation){
        self.restaurant = restaurant
    }
    
    var dateClosedRange: ClosedRange<Date> {
        let min = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
        let max = Calendar.current.date(byAdding: .day, value: 1, to: Date())!
        return min...max
    }
     
    func validateForm(){
        ErrorCodes = []
        errorMessage = "Found these errors in the form:\n\n"
        
        validatePhone()
        validateName()
        validateEmail()
        
        
        if ErrorCodes.count > 0 {
            if ErrorCodes.contains(0){
                errorMessage.append(ErrorMap[0]!)
            }
            
            if ErrorCodes.contains(1){
                var addNewLine = false
                if ErrorCodes.contains(0) {
                    addNewLine = true
                }
                errorMessage.append("\(addNewLine ? "\n\n": "")\(ErrorMap[1]!)")
            }
            
            if ErrorCodes.contains(2) {
                var addNewLine = false
                if ErrorCodes.contains(1) || ErrorCodes.contains(0){
                    addNewLine = true
                }
                errorMessage.append("\(addNewLine ? "\n\n": "")\(ErrorMap[2]!)")
            }
            
            showFormInvalidMessage = true
            return
        }
        
        updateReservation()
        self.presentationMode.wrappedValue.dismiss()
    }
   
    func validateName(){
        var valid:Bool = true
        if name.count < 3  {
            valid = false;
        }
        
        for chr in name {
            if (!chr.isLetter && String(chr) != " ") {
                valid = false;
                break;
            }
        }
  
        if !valid {
            ErrorCodes.append(0)
        }
    }
    
    func validatePhone(){
        if phone.count == 0  { //|| phone.count != 10
            ErrorCodes.append(1)
        }
    }
    
    func validateEmail() {
        var valid = true
        if email.count > 100 {
           valid = false
        }
        else {
            let emailFormat = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*(\\.[A-Za-z]{2,})$"
            let emailPredicate = NSPredicate (format:"SELF MATCHES %@", emailFormat)

            valid = emailPredicate.evaluate (with: email)
        }
        if !valid {
            ErrorCodes.append(2)
        }
    }
    
    func updateReservation(){
        let temporaryReserv = Reservation(restaurant:restaurant, customerName:name,customerEmail: email,customerPhoneNumber:phone, resrvationDate:reservationDate, party:party,specialRequest: specialRequests)
      //  model.re = restaurant
        model.reservation = temporaryReserv
      //model.mustChangeReservation.toggle()
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 15) {
                HStack {
                    RestaurantView(restaurant)
                    Spacer()
                }
            
                Divider()
                    
                HStack{
                    VStack(alignment: .leading){
                        Text("PARTY").padding([ .bottom], 8)
                        TextField("1", text: $party)
                            .frame(width: 40,alignment: .center)
                            .keyboardType(/*@START_MENU_TOKEN@*/.numberPad/*@END_MENU_TOKEN@*/)
                            .onChange(of: party, perform: { newValue in
                                party = newValue == "0" ? "1" : newValue
                            })
                        }

                    DatePicker(
                        selection: $selectedDate,
                        in: dateClosedRange,
                        displayedComponents: [.date, .hourAndMinute],
                        label: { Text("") } )
                }
                
                VStack {
                    Divider()
                    HStack{
                        Text("NAME:")
                        TextField("Your name...", text: $name )
                    }
                    Divider()
                    HStack{
                        Text("PHONE:")
                        TextField("Your phone number...", text: $phone )
                    }
                    
                    Divider()
                    HStack{
                        Text("EMAIL:")
                        TextField("Your email...", text: $email )
                    }
                    Divider()
                }
            
                TextField("Add any special request (optional)", text: $specialRequests)
                    .padding()
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.gray.opacity(0.2)))
                
                Divider()
                
                Button("CONFIRM RESERVATION"){
                    validateForm()
                }
                .padding([.leading, .trailing], 30)
                .padding([.top, .bottom], 10)
                .background(Color.blue)
                .foregroundColor(Color.white)
                .cornerRadius(20)
                .padding(.top, 0)
                .alert(isPresented: $showFormInvalidMessage ){
                    Alert(title: Text("ERROR"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
                }
            }
            .frame(maxHeight: .infinity)
            .onAppear(){
                model.displayingReservationForm = true
            }
            .onDisappear(){
                model.displayingReservationForm = false
            }
        }
        .padding([.leading, .trailing], 32)
    }
}


struct ReservationForm_Previews: PreviewProvider {
    static var previews: some View {
        let restaurant = RestaurantLocation(city: "", neighborhood: "", number: "")
        ReservationForm(restaurant)
            .environmentObject(Model())
    }
}
