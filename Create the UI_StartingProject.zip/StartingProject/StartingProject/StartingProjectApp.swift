//
//  StartingProjectApp.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/16/23.
//

import SwiftUI

@main
struct StartingProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
