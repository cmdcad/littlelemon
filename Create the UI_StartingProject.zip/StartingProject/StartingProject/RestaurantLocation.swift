//
//  RestaurantLocation.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/20/23.
//

import SwiftUI

struct RestaurantLocation: View, Identifiable {
    @EnvironmentObject var model:Model
    let id = UUID()
    var city: String
    var neighborhood: String
    var number: String
   
    var body: some View {
        VStack{
            Text(city)
                .font(.title2)
                .frame(maxWidth:.infinity, alignment: .leading)
            Text("\(neighborhood) - \(number)")
                    .font(.subheadline)
                    .frame(maxWidth:.infinity, alignment: .leading)
                    .foregroundColor(Color.gray)
          }
    }
}

struct RestaurantLocation_Previews: PreviewProvider {
    static var previews: some View {
        let temp = Model.getBranches()[0]
        
        RestaurantLocation(city: temp.city, neighborhood: temp.neighborhood, number: temp.number)
    }
}
