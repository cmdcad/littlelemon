//
//  Recipe.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/27/23.
//

import Foundation

struct Recipe {
    var orderCount: Int = 0
    
    mutating func incrementOrderCount(){
        orderCount += 1
    }
}
