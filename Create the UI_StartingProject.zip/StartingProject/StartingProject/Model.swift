//
//  Model.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/16/23.
//

import Foundation

@MainActor class Model: ObservableObject {
    @Published var tabViewSelectedIndex: Int = 0
    @Published var tabBarChanged: Bool = false;
    @Published var displayingReservationForm: Bool = false
    @Published var restaurants: [RestaurantLocation] = getBranches()
    @Published var reservation: Reservation?
   /* @Published var restaurantLocation: RestaurantLocation = RestaurantLocation(city: "Las Vegas",
                                                           neighborhood: "Downtown",
                                                           number: "(702) 555-9898")
    */
    
    static func getBranches() -> [RestaurantLocation] {
       return [
        RestaurantLocation(city: "Las Vegas",
                           neighborhood: "Downtown",
                           number: "(702) 555-9898"),
        RestaurantLocation(city: "Los Angeles",
                           neighborhood: "North Hollywood",
                           number: "(213) 555-1453"),
        RestaurantLocation(city: "Los Angeles",
                           neighborhood: "Venice",
                           number: "(310) 555-1222"),
        RestaurantLocation(city: "Nevada",
                           neighborhood: "Venice",
                           number: "(725) 555-5454"),
        RestaurantLocation(city: "San Francisco",
                           neighborhood: "North Beach",
                           number: "(415) 555-1345"),
        RestaurantLocation(city: "San Francisco",
                           neighborhood: "Union Square",
                           number: "(415) 555-9813")
      ]
    }
}


