//
//  LocationsView.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/16/23.
//

import SwiftUI

struct LocationsView: View {
    @EnvironmentObject var model:Model
    
    var body: some View {
        VStack {
            LittleLemonLogo()
            .padding(.top, 20)
 
            Text(model.displayingReservationForm ? "Reservation Details" : "Select a location")
            .padding([.leading, .trailing], 40)
            .padding([.top, .bottom], 8)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(20)

            NavigationView {
                List (model.restaurants) { restaurant in
                    NavigationLink(destination: ReservationForm(restaurant)) {
                            restaurant
                    }
                    .navigationBarTitle("")
                    .navigationBarHidden(true)
                }
                .listStyle(.plain)
                .padding()
            }
            
            .onDisappear {
                if model.tabBarChanged {return}
                // this changes the phrase from "Select a location"
                // to "RESERVATION"
                model.displayingReservationForm = true
            }
            //.frame(maxHeight: .infinity) 
        }
    }
}

struct LocationsView_Previews: PreviewProvider {
    static var previews: some View {
        LocationsView()
            .environmentObject(Model())
    }
}
