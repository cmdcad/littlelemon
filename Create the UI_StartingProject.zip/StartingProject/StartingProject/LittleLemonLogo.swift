//
//  LittleLemonLogo.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/16/23.
//

import SwiftUI

struct LittleLemonLogo: View {
    var body: some View {
        Image("littleLemonLogo")
    }
}

struct LittleLemonLogo_Previews: PreviewProvider {
    static var previews: some View {
        LittleLemonLogo()
    }
}
