//
//  ReservationView.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/20/23.
//
import SwiftUI

struct ReservationView: View {
    @EnvironmentObject var model:Model
 
    var body: some View {
        // you can create variables inside body
        // to help you reduce code repetition
         
        ScrollView {
            Group {
                LittleLemonLogo()
                    .padding(.vertical, 20)
                
                if let reservation = model.reservation {
                    VStack {
                        Text("RESERVATION")
                            .padding([.leading, .trailing], 40)
                            .padding([.top, .bottom], 8)
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(20)
                            .padding(.bottom, 20)
                        
                        
                        HStack {
                            VStack (alignment: .leading) {
                                Text("RESTAURANT")
                                    .font(.subheadline)
                                    .padding(.bottom, 5)
                                RestaurantView(reservation.restaurant)
                            }
                            Spacer()
                        } 
                        .padding(.bottom, 20)
                        
                        Divider()
                            .padding(.bottom, 20)
                        
                        
                        VStack {
                            HStack {
                                Text("NAME: ")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                
                                Text(reservation.customerName)
                                Spacer()
                            }
                            
                            HStack {
                                Text("E-MAIL: ")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                
                                Text(reservation.customerEmail)
                                Spacer()
                            }
                            
                            HStack {
                                Text("PHONE: ")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                
                                Text(reservation.customerPhoneNumber)
                                Spacer()
                            }
                            
                        }
                        .padding(.bottom, 20)
                        
                        
                        HStack {
                            Text("PARTY: ")
                                .foregroundColor(.gray)
                            
                                .font(.subheadline)
                            
                            Text(reservation.party)
                            Spacer()
                        }
                        .padding(.bottom, 20)
                        
                        VStack {
                            HStack {
                                Text("DATE: ")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                
                                Text(reservation.resrvationDate, style: .date)
                                Spacer()
                            }
                            
                            HStack {
                                Text("TIME: ")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                
                                Text(reservation.resrvationDate, style: .time)
                                Spacer()
                            }
                        }
                        .padding(.bottom, 20)
                        
                        HStack {
                            VStack (alignment: .leading) {
                                Text("SPECIAL REQUESTS:")
                                    .foregroundColor(.gray)
                                    .font(.subheadline)
                                Text(reservation.specialRequest)
                            }
                            Spacer()
                        }
                    }
                    .padding(.horizontal, 32)
                }
                else {
                        // if city is empty no reservation has been
                        // selected yet, so, show the following message
                        Text("No Reservation Yet")
                            .foregroundColor(.gray)
                            .padding(.top, 50)
                }
            }
        }
    }
}

struct ReservationView_Previews: PreviewProvider {
    static var previews: some View {
        ReservationView().environmentObject(Model())
    }
}
