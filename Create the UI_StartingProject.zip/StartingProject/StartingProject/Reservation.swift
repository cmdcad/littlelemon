//
//  Reservation.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 8/25/23.
//

import Foundation

struct Reservation  {
    var restaurant: RestaurantLocation!
    var customerName: String = ""
    var  customerEmail: String = ""
    var  customerPhoneNumber: String = ""
    var  resrvationDate: Date!
    var  party: String = ""
    var specialRequest: String = ""
}

 
