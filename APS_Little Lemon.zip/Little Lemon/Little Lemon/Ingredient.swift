//
//  Ingredients.swift
//  StartingProject
//
//  Created by Tosin Akinbobuyi on 9/7/23.
//

import Foundation

enum Ingredient: String, Codable {
    case spinach = "Spinach"
    case broccoli = "Broccoli"
    case carrot = "Carrot"
    case pasta = "Pasta"
    case tomato = "Tomato"
}
