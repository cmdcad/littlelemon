//
//  MenuItemsCategoryView.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

struct MenuItemsCategoryView: View {
    @EnvironmentObject var model: MenuViewViewModel
    var menuItems: [MenuItem]
    var title: String = ""
    
    init(menuItems: [MenuItem], title: String){
        self.title = title
        self.menuItems = menuItems
    }
    
    var body: some View {
        let col = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
        VStack(alignment: .leading) {
            Text(title)
            LazyVGrid(columns: col) {
                ForEach(menuItems, id:\.self) { item in
                    NavigationLink(destination:  MenuItemDetailView(menuItem: item)) {
                        VStack{
                            Rectangle()
                                .background(.gray)
                                .frame(height: 80)
                            Text(item.title)
                                .font(.caption)
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
        .padding()
    }
    
//    func getGridItems(data: [MenuItem]) -> [[MenuItem]]{
//        return [[]]
//    }
}

struct MenuItemsCategoryView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemsCategoryView(menuItems: [], title: "Title")
    }
}
