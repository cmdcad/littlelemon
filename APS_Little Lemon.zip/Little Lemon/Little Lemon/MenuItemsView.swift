//
//  MenuItemsView.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

struct MenuItemsView: View {
    @EnvironmentObject var model: MenuViewViewModel
    @State var showPopover: Bool = false
    
    
    var body: some View {
        NavigationView {
            ScrollView {
                MenuItemsCategoryView(menuItems: model.foods, title: "Food")
                MenuItemsCategoryView(menuItems: model.desserts, title: "Dessert")
                MenuItemsCategoryView(menuItems: model.drinks, title: "Drink")
            }
            .listRowInsets(EdgeInsets())
            .navigationTitle("Menu")
            .navigationBarItems(trailing: Button(action: {
                self.showPopover = true }){
                Image(systemName: "slider.horizontal.3")
                }
                .popover(isPresented:  $showPopover){
                    MenuItemsOptionsView()
                        .padding()
                })
        }
    }
}

struct MenuItemsView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemsView()
            .environmentObject(MenuViewViewModel())
    }
}
