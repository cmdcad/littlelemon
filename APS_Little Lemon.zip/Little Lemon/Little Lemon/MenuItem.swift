//
//  MenuItem.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import Foundation

protocol MenuItemProtocol: Identifiable, Hashable {
    var title:String { get set }
    var category: MenuCategory { get set }
    var popularity: Bool { get set }
    var ingredients: [Ingredient] { get set }
    var price: Double { get set }
    var ordersCount: Int { get set }
}

struct MenuItem: MenuItemProtocol, Identifiable, Hashable, Codable {
    
    var id: UUID
    
    var title: String
     
    var category: MenuCategory
    
    var popularity: Bool
    
    var ingredients: [Ingredient]
    
    var price: Double
    
    var ordersCount: Int
  
}


//struct MenuItem: Identifiable, Codable, Hashable {
//    var id: UUID
//    var title:String
//    var category: MenuCategory
//    var popularity: Bool
//    var ingredients: [Ingredient]
//    var price: Double
//    var ordersCount: Int
//}


