//
//  MenuItemDetailView.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

struct MenuItemDetailView: View {
    var menuItem:MenuItem
    
    var body: some View {
      
        VStack{
            Text(menuItem.title)
                .font(.title)
            
            Image("Little Lemon logo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: .infinity)
            
            VStack{
                Text("Price")
                    .font(.headline)
                Text(String(format: "%.2f", menuItem.price))
            }
            .padding()
            
            VStack{
                Text("Ordered")
                    .font(.headline)
                Text(String(menuItem.ordersCount))
            }
            .padding()
            
            VStack{
                Text("Ingredients")
                    .font(.headline)
                ForEach(menuItem.ingredients, id:\.self){ingredient in
                    Text(ingredient.rawValue)
                        .font(.callout)
                }
            }
        }
    }
}

struct MenuItemDetailView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemDetailView(menuItem: MenuItem(id: UUID(), title: "Food X", category: .food, popularity: true, ingredients: [.spinach,.pasta, .carrot], price: 12.3, ordersCount: 10))
    }
}
