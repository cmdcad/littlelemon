//
//  Little_LemonApp.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

@main
struct Little_LemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
