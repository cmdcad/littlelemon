//
//  MenuItemsOptionsView.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

struct MenuItemsOptionsView: View {
    @State private var cat2:[String] = ["Most Popular", "Price $-$$$", "A-Z"]
    
    var body: some View {
        NavigationView {
            List{
                Section(header: Text("SELECTED CATEGORY") ){
                    
                    ForEach(MenuCategory.allCases, id:\.self) { item in
                        Text(item.rawValue)
                    }
                }
                .listStyle(PlainListStyle())
               
                Section(header: Text("SORT BY") ){
                    ForEach(cat2, id:\.self) { item in
                        Text(item)
                    }
                }
                
            }
            .navigationBarTitle("Filter")
            .navigationBarItems(trailing: Button("Done"){})
        }
    }
}

struct MenuItemsOptionsView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemsOptionsView()
    }
}
