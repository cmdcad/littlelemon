//
//  ContentView.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject var model: MenuViewViewModel = MenuViewViewModel()
    
    var body: some View {
        MenuItemsView()
            .environmentObject(MenuViewViewModel())
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(MenuViewViewModel())
    }
}
