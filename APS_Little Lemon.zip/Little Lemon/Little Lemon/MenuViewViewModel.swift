//
//  ModelData.swift
//  Little Lemon
//
//  Created by Tosin Akinbobuyi on 8/30/23.
//

import Foundation 

class MenuViewViewModel: ObservableObject {
    @Published var menuItems: [MenuItem] = load2()
    
    var foods: [MenuItem] {
        menuItems.filter { $0.category == .food }
    }
    var desserts: [MenuItem] {
        menuItems.filter { $0.category == .dessert }
    }
    var drinks: [MenuItem] {
        menuItems.filter { $0.category == .drink }
    }

    var categories: [String: [MenuItem]] {
        Dictionary(
            grouping: menuItems,
            by: { $0.category.rawValue }
        )
    }
}

func load2() -> [MenuItem]{
    var menus:[MenuItem] = []
     
    for i in 1...12{
        menus.append(MenuItem(id: UUID(), title: "Food\(i)", category: .food, popularity: false, ingredients: [.broccoli, .carrot, .tomato ], price: Double.random(in: 5.0..<15.0), ordersCount: 1000))
    }
    
    for i in 1...8{
        menus.append(MenuItem(id: UUID(), title: "Dessert\(i)", category: .drink, popularity: false, ingredients: [.tomato, .pasta, .spinach ], price: Double.random(in: 5.0..<15.0), ordersCount: 1000))
    }
    
    for i in 1...4{
        menus.append(MenuItem(id: UUID(), title: "Drink\(i)", category: .drink, popularity: false, ingredients: [.broccoli, .carrot, .tomato ], price: Double.random(in: 5.0..<15.0), ordersCount: 1000))
    }
    
    return menus
}

func load() -> [MenuItem]{
    
    guard let file = Bundle.main.url(forResource: "menus", withExtension: "json") else {
        fatalError("menus.json not found")
    }
    
    let data: Data
    do {
        data = try Data(contentsOf: file)
    }catch{
        fatalError("Couldn't load menus.json")
    }
    
    
    do {
        return try JSONDecoder().decode([MenuItem].self, from: data)
    }
    catch {
        fatalError("Couldn't parse menus.json")
    }
}


//
//    func load<T: Decodable>(_ filename: String) -> T {
//        let data: Data
//
//        guard let file = Bundle.main.url(forResource: filename, withExtension: nil)
//        else {
//            fatalError("Couldn't find /Users/tosinakinbobuyi_mac/Library/Mobile Documents/com~apple~CloudDocs/Documents/XCODE PROJECTS/Swift UI/Landmarks/Landmarks/Model/ModelData.swift\(filename) in main bundle.")
//        }
//
//        do {
//            data = try Data(contentsOf: file)
//        } catch {
//            fatalError("Couldn't load \(filename) from main bundle:\n\(error)")
//        }
//
//        do {
//            let decoder = JSONDecoder()
//            return try decoder.decode(T.self, from: data)
//        } catch {
//            fatalError("Couldn't parse \(filename) as \(T.self):\n\(error)")
//        }
//    }


//    let d = """
//[
//{
//        "id": 111,
//        "title":"Pizza",
//        "ingredients": "String",
//        "price": 12.23,
//        "orderCount": 1000,
//        "category": "Food",
//        "popularity": true
//}
//]
//""".data(using: .utf8)!
