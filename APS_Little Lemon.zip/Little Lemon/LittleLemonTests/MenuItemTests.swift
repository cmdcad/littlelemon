//
//  MenuItemTests.swift
//  LittleLemonTests
//
//  Created by Tosin Akinbobuyi on 9/10/23.
//

import XCTest
@testable import Little_Lemon

class MenuItemTests: XCTestCase {
    
    func test_menuItemTitle_init_menuItemTitleEqualsInitializedValue() {
        
        let menuItem: MenuItem = MenuItem(id: UUID(),
                                          title: "Food Y",
                                          category: .food, popularity: true, ingredients: [.spinach,.pasta, .carrot], price: 12.3, ordersCount: 10)
        
        let expected = "Food Y"
        XCTAssert(menuItem.title == expected)
    }

    func test_menuItemTitle_init_menuItemTitleEqualsInitializedValue2()  {
        
        let menuItem: MenuItem = MenuItem(id: UUID(), title: "Food Y", category: .food, popularity: true,
                                          ingredients: [.pasta],
                                          price: 12.3, ordersCount: 10)
        
        let expectedIngredients:[Ingredient] = [.pasta]
        XCTAssert(menuItem.ingredients == expectedIngredients)
    }
}
